var express = require('express');
var app = express();

// set the view engine to ejs
app.set('view engine', 'ejs');
app.use( express.static( "public" ) );

// use res.render to load up an ejs view file

// index page
app.get('/', function(req, res) {
  res.render('pages/index');
});

// single page
app.get('/single-post', function(req, res) {
  res.render('pages/single-post');
});

// all-categories page
app.get('/all-categories', function(req, res) {
  res.render('pages/all-categories');
});

// CategorY Post
app.get('/category-posts', function(req, res) {
  res.render('pages/category-posts');
});


app.listen(8080);
console.log('Server is listening on port 8080');